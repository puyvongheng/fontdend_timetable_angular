import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-KX7KNOBO.js";
import "./chunk-KBWIVJWT.js";
import "./chunk-F7VJLCZX.js";
import "./chunk-7LSXWQD5.js";
import "./chunk-WDMUDEB6.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
//# sourceMappingURL=primeng_config.js.map
