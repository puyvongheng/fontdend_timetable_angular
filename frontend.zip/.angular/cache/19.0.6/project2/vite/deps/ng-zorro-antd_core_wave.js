import {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
} from "./chunk-OBPQKZLT.js";
import "./chunk-KNQQBKJJ.js";
import "./chunk-YV37426G.js";
import "./chunk-KYMFDNVD.js";
import "./chunk-PCC2KS3Y.js";
import "./chunk-XMVPNREB.js";
import "./chunk-F6G3ERJY.js";
import "./chunk-F7VJLCZX.js";
import "./chunk-7LSXWQD5.js";
import "./chunk-WDMUDEB6.js";
export {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
};
//# sourceMappingURL=ng-zorro-antd_core_wave.js.map
