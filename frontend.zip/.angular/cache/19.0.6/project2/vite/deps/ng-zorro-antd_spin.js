import {
  NzSpinComponent,
  NzSpinModule
} from "./chunk-ZM3PYUZ5.js";
import "./chunk-U7BYE6GQ.js";
import "./chunk-OUB7QVGM.js";
import "./chunk-AK6BWWXS.js";
import "./chunk-F7VJLCZX.js";
import "./chunk-7LSXWQD5.js";
import "./chunk-WDMUDEB6.js";
export {
  NzSpinComponent,
  NzSpinModule
};
//# sourceMappingURL=ng-zorro-antd_spin.js.map
