import {
  Button,
  ButtonClasses,
  ButtonDirective,
  ButtonIcon,
  ButtonLabel,
  ButtonModule,
  ButtonStyle
} from "./chunk-CB7BJQNV.js";
import "./chunk-YJFEQDLC.js";
import "./chunk-Z7E3FLLR.js";
import "./chunk-WVWYDMVP.js";
import "./chunk-5G7WYC4N.js";
import "./chunk-G26E3E7X.js";
import "./chunk-PDKRRKBZ.js";
import "./chunk-KX7KNOBO.js";
import "./chunk-KBWIVJWT.js";
import "./chunk-F7VJLCZX.js";
import "./chunk-7LSXWQD5.js";
import "./chunk-WDMUDEB6.js";
export {
  Button,
  ButtonClasses,
  ButtonDirective,
  ButtonIcon,
  ButtonLabel,
  ButtonModule,
  ButtonStyle
};
//# sourceMappingURL=primeng_button.js.map
