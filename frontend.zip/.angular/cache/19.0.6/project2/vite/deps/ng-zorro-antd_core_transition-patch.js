import {
  NzTransitionPatchDirective,
  NzTransitionPatchModule
} from "./chunk-ETVHSX7M.js";
import "./chunk-7LSXWQD5.js";
import "./chunk-WDMUDEB6.js";
export {
  NzTransitionPatchDirective as ɵNzTransitionPatchDirective,
  NzTransitionPatchModule as ɵNzTransitionPatchModule
};
//# sourceMappingURL=ng-zorro-antd_core_transition-patch.js.map
