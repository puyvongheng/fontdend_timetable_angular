import { Component, OnInit } from '@angular/core';
import { ApiService } from '../service/api.service';

import {  Router,  } from '@angular/router';

import {  NzIconService } from 'ng-zorro-antd/icon';

import { ArrowLeftOutline, BackwardOutline, DeleteOutline, EditOutline, HomeOutline, InsertRowAboveOutline, PieChartOutline, PlusOutline, SolutionOutline, UserOutline } from '@ant-design/icons-angular/icons';

import {  NzModalService } from 'ng-zorro-antd/modal';

import { NzNotificationService } from 'ng-zorro-antd/notification';
import { SharedModule } from '../shared/shared.module';



@Component({
  selector: 'app-timetables',
  imports: [
    SharedModule,
],
  templateUrl: './timetables.component.html',
  styleUrls: ['./timetables.component.css'],
})
export class TimetablesComponent implements OnInit {
  timetables: any[] = []; // Array to hold timetable data
  teachers: any[] = []; // Array to hold teachers data
  majors: any[] = []; // Array to hold majors data
  rooms: any[] = []; // Array to hold rooms data
  studySessions: any[] = []; // Array to hold study sessions data
  isLoading: boolean = false; // Indicator for data loading
  message: any; // Replace with a proper message service if needed



  filterDay: string = '';
  filterTeacher: string = '';
  filterBatch: string = '';
  filterGeneration: string = '';
  filterGroupStudent: string = '';
  filterSemester: string = '';
  filterYear: string = '';
  filterStudyShift: string = '';
  filterMajorName: string = '';
  filterRoom: string = '';




  constructor(
    private apiService: ApiService,
    private router: Router,
    private iconService: NzIconService,
    private modal: NzModalService,
    private notification: NzNotificationService






  ) {
    this.iconService.addIcon(
      UserOutline,
      HomeOutline,
      PieChartOutline,
      InsertRowAboveOutline,
      PlusOutline,
      SolutionOutline,
      DeleteOutline,
      EditOutline,
      BackwardOutline,
      ArrowLeftOutline
    );

  }

  onBack(): void {
    window.history.back();
  }

  ngOnInit(): void {

    this.loadData();
    this.loadTimetables();//simple timetable   all data 
    //  this.loadTimetablesgroup();//group time table 
    const currentYear = new Date().getFullYear();
    this.filterYear = currentYear.toString(); // Assign current year as string
    this.LoadsessionStoragefilters()

  }
  goBack() {
    if (window.history.length > 1) {
      window.history.back();
    } else {
      console.log('No history available, cannot go back.');
    }
  }





  savesessionStoragefilters() {
    const filters = {
      filterTeacher: this.filterTeacher,
      filterBatch: this.filterBatch,
      filterGeneration: this.filterGeneration,
      filterGroupStudent: this.filterGroupStudent,
      filterSemester: this.filterSemester,
      filterYear: this.filterYear,
      filterStudyShift: this.filterStudyShift,
      filterMajorName: this.filterMajorName,
      filterRoom: this.filterRoom,
    };
    sessionStorage.setItem('timetableFilters', JSON.stringify(filters));
  }

  LoadsessionStoragefilters() {
    const savedFilters = sessionStorage.getItem('timetableFilters');
    if (savedFilters) {
      const filters = JSON.parse(savedFilters);
      this.filterTeacher = filters.filterTeacher || '';
      this.filterBatch = filters.filterBatch || '';
      this.filterGeneration = filters.filterGeneration || '';
      this.filterGroupStudent = filters.filterGroupStudent || '';
      this.filterSemester = filters.filterSemester || '';
      this.filterYear = filters.filterYear || '';
      this.filterStudyShift = filters.filterStudyShift || '';
      this.filterMajorName = filters.filterMajorName || '';
      this.filterRoom = filters.filterRoom || '';
    }
    this.filterTimetables()
  }

  clearFilters(): void {
    this.filterTeacher = '';
    this.filterBatch = '';
    this.filterGeneration = '';
    this.filterGroupStudent = '';
    this.filterSemester = '';
    this.filterYear = '';
    this.filterStudyShift = '';
    this.filterMajorName = '';
    this.filterRoom = '';
    sessionStorage.removeItem('timetableFilters');
    this.filterTimetables();
  }

















  get uniqueRoom() {
    const rooms = this.timetables.map(t => t.room_number);
    return [...new Set(rooms)];
  }
  get uniqueYears() {
    const years = this.timetables.map(t => t.years);
    return [...new Set(years)];
  }

  get uniqueStudyShifts() {
    const studyShifts = this.timetables.map(t => t.study_shift_name);
    return ['All', ...new Set(studyShifts)];
  }

  get uniqueGroupStudents() {
    const groupStudents = this.timetables.map(t => t.group_student);
    return [...new Set(groupStudents)];
  }
  get uniqueSemesters() {
    const semesters = this.timetables.map(t => t.semester);
    return [...new Set(semesters)];
  }
  get uniqueGenerations() {
    const generations = this.timetables.map(t => t.generation);
    return [...new Set(generations)];
  }
  get uniqueMajors() {
    const majors = this.timetables.map(t => t.major_name);
    return [...new Set(majors)];
  }
  get uniqueBatch() {
    const batches = this.timetables.map(t => t.batch);
    return [...new Set(batches)];
  }
  get uniqueTeachers() {
    // Extract unique teacher IDs from timetables and map them to teacher names
    const teacherIds = [...new Set(this.timetables.map(t => t.teacher_id))];
    return teacherIds.map(id => ({
      id,
      name: this.findTeacher(id),
    }));
  }













  // Method to filter timetables based on the filter criteria
  filterTimetables(): void {
    this.savesessionStoragefilters()

    this.isLoading = true
    this.isLoadingupdate = true

    let filteredTimetables = this.timetables;

    if (this.filterTeacher) {
      filteredTimetables = filteredTimetables.filter(entry =>
        this.findTeacher(entry.teacher_id).toLowerCase().includes(this.filterTeacher.toLowerCase()));
    }
    // Filter by study shift name
    if (this.filterStudyShift && this.filterStudyShift !== 'All') {
      filteredTimetables = filteredTimetables.filter(entry =>
        entry.study_shift_name.toLowerCase().includes(this.filterStudyShift.toLowerCase())
      );
    }


    // Filter based on batch
    if (this.filterBatch) {
      filteredTimetables = filteredTimetables.filter(entry => entry.batch.toString() === this.filterBatch);
    }
    // Filter based on generation
    if (this.filterGeneration) {
      filteredTimetables = filteredTimetables.filter(entry => entry.generation.toString() === this.filterGeneration);
    }
    // Filter based on group_student
    if (this.filterGroupStudent) {
      filteredTimetables = filteredTimetables.filter(entry => entry.group_student.toString() === this.filterGroupStudent);
    }
    // Filter based on semester
    if (this.filterSemester) {
      filteredTimetables = filteredTimetables.filter(entry => entry.semester.toString() === this.filterSemester);
    }

    // Filter based on year
    if (this.filterYear) {
      filteredTimetables = filteredTimetables.filter(entry => entry.years.toString() === this.filterYear);
    }

    // Filter based on major_name
    if (this.filterRoom) {
      filteredTimetables = filteredTimetables.filter(entry => entry.room_number.toString() === this.filterRoom);
    }

    if (this.filterMajorName) {
      filteredTimetables = filteredTimetables.filter(entry => entry.major_name.toString() === this.filterMajorName);
    }

    // Group by time and day after filtering
    this.groupedTimetables = this.groupTimetablesByTimeAndDay(filteredTimetables);
    this.isLoading = false
    this.isLoadingupdate = false

  }


  groupTimetablesByTimeAndDay(timetables: any[]): any[] {
    this.isLoading = true
    if (!timetables || timetables.length === 0) return []; // Handle empty input​​​ ​Saturday​ Sunday  "​Saturday​"

    const validDays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
    const grouped: any[] = [];

    timetables.forEach((entry) => {
      const {
        session_time_start,
        session_time_end,
        study_session_day,
        study_sessions_id,
        study_shift_name,
        subject_name,
        teacher_id,
        room_id,
        room_number,
        id,
        major_name,
        generation,
        batch,

      } = entry;

      if (!validDays.includes(study_session_day)) return; // Skip invalid days

      const timeRange = `${session_time_start} - ${session_time_end} `;

      // Check if the time slot exists in the grouped array
      let timeSlot = grouped.find((slot) => slot.time === timeRange);

      if (!timeSlot) {
        // If not found, create a new time slot entry
        timeSlot = { time: timeRange };
        grouped.push(timeSlot);
      }

      // Add the entry under the corresponding day
      timeSlot[study_session_day] = {
        subject_name,
        teacher_id,
        room_id,
        study_sessions_id,
        study_shift_name,
        generation,
        room_number,
        batch,
        major_name,
        id,
      };
    });

    // Optionally sort the grouped array by time for better presentation
    grouped.sort((a, b) => {
      const [aStart] = a.time.split(" - ");
      const [bStart] = b.time.split(" - ");
      return new Date(`1970/01/01 ${aStart}`).getTime() - new Date(`1970/01/01 ${bStart}`).getTime();
    });
    this.isLoading = false

    return grouped;
  }
  groupedTimetables: any[] = [];
  formatTime(time: string): string {
    const [hours, minutes] = time.split(':');
    const period = +hours >= 12 ? 'PM' : 'AM';
    const formattedHours = +hours > 12 ? +hours - 12 : +hours;
    return `${formattedHours}:${minutes} ${period}`;
  }







  // Load related data (teachers, majors, rooms, study sessions)
  loadData(): void {
    this.isLoading = true;
    // Fetch teachers
    this.apiService.getTeachers().subscribe(
      (response) => (this.teachers = response),
      (error) => console.error('Error loading teachers:', error)
    );
    // Fetch majors
    this.apiService.getMajors().subscribe(
      (response) => (this.majors = response),
      (error) => console.error('Error loading majors:', error)
    );

    // Fetch rooms
    this.apiService.getRooms().subscribe(
      (response) => (this.rooms = response),
      (error) => console.error('Error loading rooms:', error)
    );
    // Fetch study sessions
    this.apiService.getStudySessions().subscribe(
      (response) => (this.studySessions = response),
      (error) => console.error('Error loading study sessions:', error)
    );


  }



  // Fetch all timetables  
  loadTimetables(): void {
    this.isLoading = true
    this.apiService.getTimetable().subscribe(
      (response) => {
        this.timetables = response.timetable_entries || response;
        this.isLoading = false;
      },
      (error) => {
        console.error('Error loading timetables:', error);
        this.message?.error('Failed to load timetables');
        this.isLoading = false;
      }
    );

  }


  loadTimetablesgroup(): void {
    this.isLoading = true
    this.apiService.get('timetable').subscribe(
      (response) => {
        this.timetables = response.timetable_entries || response;
        this.isLoading = false;

        // Grouping by time and day
        this.groupedTimetables = this.groupTimetablesByTimeAndDay(this.timetables);
      },
      (error) => {
        console.error('Error loading timetables:', error);
        this.message?.error('Failed to load timetables');
        this.isLoading = true;
      }
    );
  }




  // Find teacher name by ID
  findTeacher(teacherId: number): string {
    const teacher = this.teachers.find((t) => t.id === teacherId);
    return teacher ? teacher.name : 'Unknown';
  }
  // Find room details by ID
  findRoom(roomId: number): any {
    return this.rooms.find((r) => r.id === roomId) || { room_type: 'Unknown', room_number: 'Unknown', floor: 'Unknown', capacity: 'Unknown' };
  }
  findStudySession(sessionId: number): any | null {
    const session = this.studySessions.find((s) => s.id === sessionId);
    return session || null;
  }


  // Find subject name by ID
  findSubject(subjectId: number): string {
    const subject = this.majors.find((s) => s.id === subjectId);
    return subject ? subject.major_name : 'Unknown';
  }




  // edit 
  editTimetable(timetableId: number): void {
    this.router.navigate([`/timetables/edit`, timetableId]);
  }
  // delet

  isLoadingupdate: boolean = false;

  deleteTimetable(id: number): void {
    // Show Ant Design modal for confirmation
    this.modal.confirm({
      nzTitle: 'Are you sure you want to delete this ?',
      nzContent: '<b style="color: red;">     .</b>',
      nzOkText: 'Yes',
      nzOkType: 'primary',
      nzOkDanger: true,
      nzOnOk: () => {
        // Delete timetable when user confirms
        this.apiService.delete('timetable', id).subscribe(
          () => {
            this.isLoadingupdate = true


            this.loadTimetables()
            this.loadTimetablesgroup()



            setTimeout(() => {
              this.filterTimetables();
              this.isLoadingupdate = false
            }, 1000); // 1 seconds delay

            this.notification.success(
              'ជោគជ័យ',
              'បានdeleteដោយជោគជ័យ! '
            );




            // Show success message
          },
          (error) => {
            this.isLoadingupdate = false

            this.notification.error(
              'បារាជ័យជោគជ័យ',
              'បានdelete! '
            );


          }
        );
      },
      nzCancelText: 'No',
      nzOnCancel: () => {
        // Reset loading state if deletion is cancelled
        this.isLoadingupdate = false;
        console.log('Delete action cancelled');
      },
    });
  }




}
