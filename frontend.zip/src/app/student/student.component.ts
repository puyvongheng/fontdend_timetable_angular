import { Component, CUSTOM_ELEMENTS_SCHEMA, OnInit } from '@angular/core';
import { ApiService } from '../service/api.service';

import { ManagementStudenRegisterComponent } from "../management-studen-register/management-studen-register.component";

import { SharedModule } from '../shared/shared.module';

declare var bootstrap: any; // Use this to access Bootstrap from the CDN


@Component({
  selector: 'app-student',
  imports: [
    SharedModule,
    ManagementStudenRegisterComponent
  
  
  ],
  templateUrl: './student.component.html',
  styleUrl: './student.component.css',
  schemas: [CUSTOM_ELEMENTS_SCHEMA], // Add this line

})

export class StudentComponent implements OnInit {
  students: any[] = []; // Array to hold students data
  majors: any[] = [];   // Array to hold majors data from the API
  studentId: number | null = null; // ID of the student being edited
  username: string = '';
  name: string = '';
  password: string = '';
  majorId: number | null = null;
  generation: string = '';
  batch: string = '';
  groupStudent: string = '';

  totalStudents: number = 0;
  currentPage: number = 1;
  pageSize: number = 10;
  message: any;


  openAddStudentModal(): void {
    this.resetForm(); // Reset the form fields before opening the modal
    const modal = new bootstrap.Modal(document.getElementById('studentModal')!);
    modal.show();
  }

  closeModal(): void {
    const modalElement = document.getElementById('studentModal');
    if (modalElement) {
      const modal = bootstrap.Modal.getInstance(modalElement);
      modal?.hide();
    }
  }



  showTableView: boolean = true;

  toggleView() {
    this.showTableView = !this.showTableView;
  }

  viewOptions = [
    { label: 'Show Table View', value: true },
    { label: 'Show Card View', value: false }
  ];






  onPageChange(page: number): void {
    // Save the current page number to localStorage when the page changes
    localStorage.setItem('currentPage', page.toString());
    this.currentPage = page;
    this.loadStudents(this.currentPage, this.pageSize);  // Re-fetch students based on the new page number
  }

  // Call this function when the page size changes
  onPageSizeChange(pageSize: number): void {
    // Update the page size
    this.pageSize = pageSize;
    // Recalculate the current page if the total number of students has changed
    const totalPages = Math.ceil(this.totalStudents / this.pageSize);
    // If the current page is greater than the total pages after changing the page size, reset to the last available page
    if (this.currentPage > totalPages) {
      this.currentPage = totalPages;
    }
    // Re-fetch students based on the new page size and adjusted current page
    this.loadStudents(this.currentPage, this.pageSize);
  }

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.loadStudents(this.currentPage, this.pageSize); // Load students on component init

    this.load();
  }

  load() {

    // this.apiService.getStudents().subscribe((response: any) => { this.students = response; });

    this.apiService.getMajors().subscribe((response: any) => { this.majors = response; });
    this.loadStudents();

  }


  loadStudents(page: number = 1, pageSize: number = 10): void {
    // Get the saved page number from localStorage (if exists), otherwise use the provided default
    const savedPage = localStorage.getItem('currentPage');
    this.currentPage = savedPage ? +savedPage : page; // Use saved page or default to 1

    this.apiService.getstuden('students', this.currentPage, pageSize).subscribe(
      (data) => {
        this.students = data.students; // Assuming the API sends students in this format
        this.totalStudents = data.totalStudents; // Assuming API sends total number of students
      },
      (error) => {
        console.error('Error loading students:', error);
      }
    );
  }




  // Add a new student
  addStudent(): void {
    if (this.username && this.name && this.password && this.majorId) {
      const newStudent = {
        username: this.username,
        name: this.name,
        password: this.password,
        major_id: this.majorId,
        generation: this.generation,
        batch: this.batch,
        group_student: this.groupStudent
      };

      this.apiService.create('students', newStudent).subscribe(() => {
        this.loadStudents(); // Reload students after adding
        this.resetForm(); // Reset the form after adding
        this.closeModal(); // Close the modal
      });
    } else {
      alert('All fields are required!');
    }
  }



  updateStudent(id: any

  ) {
    const updatedStudent = {
      id: this.studentId,
      username: this.username,
      student_name: this.name,
      password: this.password,
      majorId: this.majorId,
      generation: this.generation,
      batch: this.batch,
      group_student: this.groupStudent,
    };
    const index = this.students.findIndex((s) => s.id === this.studentId);
    if (index !== -1) {
      this.students[index] = updatedStudent;
    }
    this.closeModal(); // Use Bootstrap method to close modal
    this.resetForm(); // Reset form fields
  }



  // Delete a student
  deleteStudent(id: number): void {
    if (confirm('Are you sure you want to delete this student?')) {
      this.apiService.delete('students', id).subscribe(() => {
        // After deleting, we need to check if the current page still has students
        const newTotalStudents = this.totalStudents - 1;

        // If current page has no students, go to the previous page (or stay on the current page if it's the first page)
        if (newTotalStudents <= (this.currentPage - 1) * this.pageSize) {
          this.currentPage = Math.max(1, this.currentPage - 1);  // Avoid going to page 0
        }

        this.totalStudents = newTotalStudents;
        this.loadStudents(this.currentPage, this.pageSize); // Reload students on the new page
      });
    }
  }



  // Reset the form
  resetForm(): void {
    this.studentId = null;
    this.username = '';
    this.name = '';
    this.password = '';
    this.majorId = null;
    this.generation = '';
    this.batch = '';
    this.groupStudent = '';
  }
}