import { ApplicationConfig, provideZoneChangeDetection, importProvidersFrom } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';

import { routes } from './app.routes';
import { en_US, provideNzI18n } from 'ng-zorro-antd/i18n';
import { registerLocaleData } from '@angular/common';
import en from '@angular/common/locales/en';
import { FormsModule } from '@angular/forms';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { RoleGuard } from './role.guard';
import { providePrimeNG } from 'primeng/config';
import Aura from '@primeng/themes/aura';

registerLocaleData(en);

export const appConfig: ApplicationConfig = {
  providers: [//added providers
    RoleGuard,

    provideAnimationsAsync(),
    providePrimeNG({
      theme: {
        preset: Aura,
        options: {

          darkModeSelector: '.my-app-dark',

          ripple: true,              // Enable ripple effect
          theme: 'aura',             // Set the theme to 'Aura'
          prefix: 'p',               // Set the prefix to 'p'
          cssLayer: false,
          // Disable CSS layers
        }

      }
    }),



    provideZoneChangeDetection({ eventCoalescing: true }),//added provideZoneChangeDetection
    provideRouter(routes),//added provideRouter
    provideHttpClient(), provideNzI18n(en_US), importProvidersFrom(FormsModule), provideAnimationsAsync(), provideHttpClient() // Added HttpClientModule provider
  ]
};
