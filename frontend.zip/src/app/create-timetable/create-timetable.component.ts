import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { TimetableService } from '../service/timetable.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { ApiService } from '../service/api.service';
import { SharedModule } from '../shared/shared.module';

interface StudySession {
  id: string;
  shift_name: string;
  sessions_day: string;
  session_time_start: string;
  session_time_end: string;
}

interface Major {
  id: string;
  major_name: string;
}

interface Teacher {
  id: string;
  name: string;
  number_sessions?: number;
  totalTimetable?: number;


}

interface Subject {
  id: string;
  name: string;
}

interface Room {
  id: string;
  room_number: string;
}


interface TeacherSubject {
  teacher_id: string;
  subject_id: string;
}


@Component({
  selector: 'app-create-timetable',
  imports: [    SharedModule,
  
  ],
  templateUrl: './create-timetable.component.html',
  styleUrl: './create-timetable.component.css'
})
export class CreateTimetableComponent implements OnInit {
  timetableForm = {
    note: '',
    study_sessions_id: '',
    group_student: '',
    batch: '',
    generation: '',
    major_id: '',
    teacher_id: '',
    subject_id: '',
    room_id: '',
    years: '',
    semester: '1'
  };
  message: string = '';
  messages: string[] = [];
  alertClass: string = '';
  studySessions: StudySession[] = [];

  majors: Major[] = [];
  teachers: Teacher[] = [];
  subjects: Subject[] = [];

  teacherSubjects: TeacherSubject[] = [];
  filteredTeachers: Teacher[] = [];
  filteredSubjects: Subject[] = [];

  rooms: Room[] = [];

  isLoading: boolean = false;

  isEditMode: boolean = false; // Determines if the component is in edit mode
  timetableId: string | null = null; // Stores the timetable ID for editing

  constructor
    (
      private timetableService: TimetableService,
      private router: Router,
      private route: ActivatedRoute,
    private notification: NzNotificationService,
    private apiService: ApiService,


  ) { }
  


  goBack() {
    if (window.history.length > 1) {
      window.history.back();
    } else {
      console.log('No history available, cannot go back.');
    }
  }




  ngOnInit(): void {
    this.timetableForm.years = new Date().getFullYear().toString(); //2025
    this.loadDropdownData();

    this.route.queryParams.subscribe((params) => {
      const id = params['id'];
      if (id) {
        this.loadTimetableForEdit(id); // Call the function to load the timetable
      }
    });

    this.loadDropdownData();


    if (this.timetableId) {
      this.isEditMode = true; // Switch to edit mode
      this.loadTimetableForEdit(this.timetableId);
    }


    this.loadTeachers();

  }






  totalTimetable: number = 0;
  errorMessage: string = '';


  // Method to load teachers from the API
  loadTeachers(): void {
    this.apiService.getTeachers().subscribe(
      (response) => {
        this.teachers = response;  // Assign the response data to the teachers array
        this.teachers.forEach(teacher => {

          const currentYear = Number(this.timetableForm?.years) || new Date().getFullYear();  // Ensure currentYear is a number
          const semester = Number(this.timetableForm?.semester) || Number(1);  // Ensure semester is a number, default to 1

          this.getTotalTimetable(Number(teacher.id), currentYear, semester);  // Call getTotalTimetable with the correct values
        });
      },
      (error) => {
        this.errorMessage = 'Error loading teachers.';  // Handle the error gracefully
        console.error('Error loading teachers:', error);  // Log the error for debugging
      }
    );
  }




  getTotalTimetable(teacherId: number, year: number, semester: number): void {
    if (!teacherId) {
      console.error("Invalid teacher ID:", teacherId);
      return;
    }

    this.apiService.get(`teachers/teacher/${teacherId}/total?year=${year}&semester=${semester}`)
      .subscribe(
        (data: any) => { // Use 'any' if you don't want to define a type
          const teacher = this.teachers.find(t => Number(t.id) === teacherId);
          if (teacher) {
            teacher.totalTimetable = data.total_timetable ?? 0;
          } else {
            console.warn(`Teacher with ID ${teacherId} not found.`);
          }
        },
        (error) => {
          console.error(`Error fetching timetable data for teacher ID ${teacherId}:`, error);
        }
      );
  }









  loadTimetableForEdit(id: string): void {
    this.timetableService.getTimetableById(id).subscribe(
      (data: any) => {
        this.isEditMode = true; // Switch to edit mode

        // Map the API response to the timetableForm structure
        const timetable = data.timetable;
        this.timetableForm = {
          note: timetable.note || '',
          study_sessions_id: timetable.study_sessions_id || '',
          group_student: timetable.group_student || '',
          batch: timetable.batch || '',
          generation: timetable.generation || '',
          major_id: timetable.major_id || '',
          teacher_id: timetable.teacher_id || '',
          subject_id: timetable.subject_id || '',
          room_id: timetable.room_id || '',
          years: timetable.years ? timetable.years.toString() : '',
          semester: timetable.semester || '1', // Default to '1' if not provided
        };

        // Additional logic for setting study session
        this.shiftName = timetable.study_shift_name || '';
        this.sessionDay = timetable.study_session_day || '';
      },
      (error) => {
        console.error('Error fetching timetable for editing:', error);
      }
    );
  }





  isTeacherFull(): boolean {
    const selectedTeacher = this.filteredTeachers.find(teacher => teacher.id === this.timetableForm.teacher_id);
    return selectedTeacher ? (selectedTeacher.totalTimetable ?? 0) - (selectedTeacher.number_sessions ?? 0) >= 0 : false;
  }

  


  conflicts: any[] = []; // Store err conflicts


  checkForConflicts(): void {
    this.loadTeachers()
    // Example data (simulated)
    const data = {
      study_sessions_id: this.timetableForm.study_sessions_id,
      years: this.timetableForm.years,
      semester: this.timetableForm.semester,
      teacher_id: this.timetableForm.teacher_id,
      room_id: this.timetableForm.room_id,
      group_student: this.timetableForm.group_student,
      generation: this.timetableForm.generation,
      major_id: this.timetableForm.major_id,

    };

    this.timetableService.checkForConflicts(data).subscribe(
      response => {
        if (response.conflicts && response.conflicts.length > 0) {
          this.conflicts = response.conflicts;
        } else {
          this.conflicts = [];
        }
      },
      error => {
        console.error('Error checking conflicts:', error);
      }
    );
  }










  //for fillter shift day 
  shiftName: string = '';
  sessionDay: string = '';
  sessionTime: string = '';
  //វេនសិក្សសា
  getUniqueShiftNames() {
    const shifts = this.studySessions.map(session => session.shift_name);
    return [...new Set(shifts)];
  }
  //ថ្ងៃ
  getUniqueDaysForShift() {
    if (!this.shiftName) return [];
    const filteredSessions = this.studySessions.filter(session => session.shift_name === this.shiftName);
    const days = filteredSessions.map(session => session.sessions_day);
    return [...new Set(days)];
  }
  //h
  getUniqueTimes() {
    if (!this.shiftName || !this.sessionDay) return []; // If no shift or day selected, return empty array
    const filteredSessions = this.studySessions.filter(session =>
      session.shift_name === this.shiftName && session.sessions_day === this.sessionDay);

    const times = filteredSessions.map(session => session.session_time_start);
    return [...new Set(times)];
  }

  //fillter
  getFilteredSessions() {
    return this.studySessions.filter(session => {
      const matchesShiftName = this.shiftName ? session.shift_name.includes(this.shiftName) : true;
      const matchesSessionDay = this.sessionDay ? session.sessions_day === this.sessionDay : true;
      const matchesSessionTime = this.sessionTime ? session.session_time_start === this.sessionTime : true;
      return matchesShiftName && matchesSessionDay && matchesSessionTime;
    });
  }
  //update fillter
  updateSelectedSession() {
    const filteredSessions = this.getFilteredSessions();
    if (filteredSessions.length > 0) {
      this.timetableForm.study_sessions_id = filteredSessions[0].id; // Automatically set the first session
    } else {
      this.timetableForm.study_sessions_id = ''; // Reset to empty string if no session found
    }

    if (!this.shiftName) {
      this.sessionDay = '';
      this.sessionTime = '';
    } else {
    }

  }



  //face data
  loadDropdownData() {
    this.loadTeachers()
    this.timetableService.getStudySessions().subscribe((data) => (this.studySessions = data));
    this.timetableService.getMajors().subscribe((data) => (this.majors = data));
    this.timetableService.getTeachers().subscribe((data) => (this.teachers = data));
    this.timetableService.getSubjects().subscribe((data) => (this.subjects = data));
    this.timetableService.getRooms().subscribe((data) => (this.rooms = data));
    this.timetableService.getTeacherSubjects().subscribe((data) => { this.teacherSubjects = data; this.filteredTeachers = this.teachers; this.filteredSubjects = this.subjects; });

  }


  //for fillter tacher  bu subject
  onTeacherChange(): void {
    this.loadTeachers()
    const selectedTeacherId = this.timetableForm.teacher_id;
    if (selectedTeacherId) {
      const subjectIds = this.teacherSubjects
        .filter(ts => ts.teacher_id === selectedTeacherId)
        .map(ts => ts.subject_id);

      this.filteredSubjects = this.subjects.filter(subject => subjectIds.includes(subject.id));
    } else {
      this.filteredSubjects = this.subjects; // Reset to all subjects if no teacher selected
    }

    // Clear selected subject if it doesn't match the filtered list
    if (!this.filteredSubjects.some(subject => subject.id === this.timetableForm.subject_id)) {
      this.timetableForm.subject_id = '';
    }
  }

  // for fillter subject buy teher
  onSubjectChange(): void {

    const selectedSubjectId = this.timetableForm.subject_id;
    if (selectedSubjectId) {
      const teacherIds = this.teacherSubjects
        .filter(ts => ts.subject_id === selectedSubjectId)
        .map(ts => ts.teacher_id);

      this.filteredTeachers = this.teachers.filter(teacher => teacherIds.includes(teacher.id));
    } else {
      this.filteredTeachers = this.teachers; // Reset to all teachers if no subject selected
    }

    //  សម្អាតគ្រូដែលបានជ្រើសរើសប្រសិនបើវាមិនត្រូវគ្នានឹងបញ្ជីដែលបានត្រង  Clear selected teacher if it doesn't match the filtered list
    if (!this.filteredTeachers.some(teacher => teacher.id === this.timetableForm.teacher_id)) {
      this.timetableForm.teacher_id = '';
    }

  }


  // Handle form submission
  onSubmit(): void {


    this.isLoading = true;
    this.messages = [];


    if (this.isEditMode && this.timetableId) {
      // Update timetable
      this.timetableService.updateTimetable(this.timetableId, this.timetableForm).subscribe(
        (response: any) => {
          this.messages.push('Timetable updated successfully!');
          this.isLoading = false;
        },
        (error) => {

          this.handleError(error);
        }
      );



    } else {
      // Create timetable
      this.timetableService.createTimetable(this.timetableForm).subscribe(
        (response: any) => {
          if (response.errors) {
            this.messages = response.errors.map((err: { error: string }) => err.error);
          } else {

            this.notification.success(
              'ជោគជ័យ',
              'បានបង្កើតដោយជោគជ័យ! '
            );



            this.messages.push('Timetable entry created successfully/ បានបង្កើតដោយជោគជ័យ');
            this.checkForConflicts()



          }
          this.isLoading = false;
        },
        (error) => {
          this.handleError(error);


          this.notification.warning(
            'កំហុស',
            'សូមពិនិត្យ និងកែប្រែព័ត៌មានខាងក្រោម មុននឹងបញ្ជូនបន្ត។! '
          );




        }




      );


    }



  }



  handleError(error: any): void {
    this.isLoading = false;
    if (error.error && error.error.errors) {
      this.messages = error.error.errors.map((err: { error: string }) => err.error);
    } else {
      this.messages.push('An error occurred. Please try again later.');
    }
    console.error('Error:', error);
  }



  resetForm(): void {
    this.timetableForm = {
      note: '',
      study_sessions_id: '',
      group_student: '',
      batch: '',
      generation: '',
      major_id: '',
      teacher_id: '',
      subject_id: '',
      room_id: '',
      years: '',
      semester: ''
    };
  }


}