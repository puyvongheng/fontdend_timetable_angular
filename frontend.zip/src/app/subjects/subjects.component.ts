
import { ApiService } from './../service/api.service';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, isFormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

import { SharedModule } from '../shared/shared.module';



@Component({
  selector: 'app-subjects',
  imports: [
 SharedModule,
  ],
  templateUrl: './subjects.component.html',
  styleUrl: './subjects.component.css'
})
export class SubjectsComponent implements OnInit {
  subjects: { id: number; name: string }[] = [];
  subjectForm: FormGroup;

  constructor(private apiService: ApiService, private fb: FormBuilder) {
    this.subjectForm = this.fb.group({
      name: ['', Validators.required], // Form control with validation
    });
  }

  ngOnInit(): void {
    this.loadData();
  }


  loadData(): void {

    this.apiService.getSubjects().subscribe(
      (response) => (this.subjects = response),
      (error) => console.error('Error loading data:', error)
    );

  }


  isEditMode: boolean = false;
  editingSubjectId: number | null = null;



  addOrUpdateSubject(): void {
    if (this.subjectForm.valid) {
      const subjectData = this.subjectForm.value;

      if (this.isEditMode && this.editingSubjectId !== null) {
        // Edit mode: Update the subject
        this.apiService.update(`subjects`, this.editingSubjectId, subjectData).subscribe(
          (response) => {
            this.loadData(); // Reload the list
            this.resetForm();
          },
          (error) => console.error('Error updating subject:', error)
        );
      } else {
        // Add mode: Create a new subject
        this.apiService.create('subjects', subjectData).subscribe(
          (response) => {
            this.subjects.push(response); // Add the new subject to the list
            this.resetForm();
          },
          (error) => console.error('Error adding subject:', error)
        );
      }
    }
  }

  editSubject(subject: { id: number; name: string }): void {
    this.isEditMode = true;
    this.editingSubjectId = subject.id;
    this.subjectForm.patchValue({ name: subject.name }); // Pre-fill the form with the subject's data
  }



  addSubject(): void {
    if (this.subjectForm.valid) {
      const newSubject = this.subjectForm.value;
      this.apiService.create('subjects', newSubject).subscribe(
        (response) => {
          this.subjects.push(response); // Add the new subject to the list
          this.subjectForm.reset(); // Clear the form
          this.loadData()
        },
        (error) => console.error('Error adding subject:', error)
      );
    }
  }

  deleteSubject(id: number): void {
    const confirmation = window.confirm('Are you sure you want to delete this subject?');
    if (confirmation) {
      this.apiService.delete('subjects', id).subscribe(
        () => {
          this.subjects = this.subjects.filter((subject) => subject.id !== id); // Remove the deleted subject from the list
          this.loadData()
        },
        (error) => console.error('Error deleting subject:', error)
      );
    }
  }

  resetForm(): void {
    this.isEditMode = false;
    this.editingSubjectId = null;
    this.subjectForm.reset();
  }


}