import { Component, OnInit } from '@angular/core';
import { ApiService } from '../service/api.service';

import { ActivatedRoute, Router, RouterModule } from '@angular/router';

import { NzMessageService } from 'ng-zorro-antd/message';
import * as XLSX from 'xlsx';
import { SharedModule } from '../shared/shared.module';

@Component({
  selector: 'app-timetables-public',
  imports: [
      SharedModule,
  
  ],
  templateUrl: './timetables-public.component.html',
  styleUrl: './timetables-public.component.css'
})
export class TimetablesPublicComponent {
  timetables: any[] = []; // Array to hold timetable data
  teachers: any[] = []; // Array to hold teachers data
  majors: any[] = []; // Array to hold majors data
  rooms: any[] = []; // Array to hold rooms data
  studySessions: any[] = []; // Array to hold study sessions data
  isLoading: boolean = false; // Indicator for data loading
  message: any; // Replace with a proper message service if needed


  filterDay: string = '';
  filterTeacher: string = '';
  filterBatch: string = '';
  filterGeneration: string = '';
  filterGroupStudent: string = '';
  filterSemester: string = '';
  filterYear: string = '';
  filterStudyShift: string = '';
  filterMajorName: string = '';
  filterRoom: string = '';



  isSaving = false;
  activeTab: number = 0; // Default to the first tab

  constructor(
    private apiService: ApiService,
    private router: Router,
    private route: ActivatedRoute,
    private NzMessageService: NzMessageService
  ) { }

  resetfillter() {
    this.filterDay = ''
    this.filterTeacher = ''
    this.filterBatch = ''
    this.filterGeneration = ''
    this.filterGroupStudent = ''
    this.filterSemester = ''
    this.filterYear = ''
    this.filterStudyShift = ''
    this.filterMajorName = ''
    this.filterRoom = ''


  }


  exportToExcel() {
    // Create an array of rows from your timetable data
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(document.getElementById('timetable-table'));
    // Create a workbook with the worksheet
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Timetable');

    // Export the workbook to a file
    XLSX.writeFile(wb, 'Timetable.xlsx');
    // Show an alert after export is complete
    alert('Timetable has been exported to Excel successfully!');
  }





  printPage() {
    window.print(); // Opens print dialog
  }

  onTabChange(index: number): void {

    this.activeTab = index;
    this.resetfillter()


  }

  getFacebookShareUrl(): string {
    const url = encodeURIComponent(this.generateDynamicUrl());
    return `https://www.facebook.com/sharer/sharer.php?u=${url}`;
  }

  getTelegramShareUrl(): string {
    const url = encodeURIComponent(this.generateDynamicUrl());
    return `https://t.me/share/url?url=${url}`;
  }

  copyQrUrl(): void {
    navigator.clipboard.writeText(this.generateDynamicUrl()).then(
      () => {

        this.NzMessageService.info('QR URL copied to clipboard!');
        // Close the modal programmatically (if `data-bs-dismiss="modal"` is not working dynamically)
        const closeModalButton = document.querySelector('.btn-close') as HTMLElement;
        closeModalButton?.click();


      },
      (err) => {
        console.error('Failed to copy QR URL:', err);
      }
    );
  }

  saveQrCodeImage(): void {
    this.isSaving = true;

    const qrCodeElement = document.querySelector('nz-qrcode');

    if (!qrCodeElement) {
      console.error('QR Code element not found.');
      this.isSaving = false;
      return;
    }

    const canvas = qrCodeElement.querySelector('canvas');

    if (!canvas) {
      console.error('QR Code canvas not found.');
      this.isSaving = false;
      return;
    }

    try {
      const imageData = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.href = imageData;

      link.download = `កាវិភាគឆ្នាំំ${this.filterYear || 'Default'} .png`;

      link.click();
      this.isSaving = false; // Reset loading state after saving
    } catch (error) {
      console.error('Error saving QR code image:', error);
      this.isSaving = false;
    }


  }

  generateDynamicUrl(): string {
    const queryParams: any = {};

    if (this.filterTeacher) queryParams.teacher = this.filterTeacher;
    if (this.filterYear) queryParams.year = this.filterYear;
    if (this.filterBatch) queryParams.batch = this.filterBatch;
    if (this.filterGeneration) queryParams.generation = this.filterGeneration;
    if (this.filterGroupStudent) queryParams.group = this.filterGroupStudent;
    if (this.filterSemester) queryParams.semester = this.filterSemester;
    if (this.filterStudyShift) queryParams.studyShift = this.filterStudyShift;
    if (this.filterMajorName) queryParams.major = this.filterMajorName;
    if (this.filterRoom) queryParams.room = this.filterRoom;
    const dynamicUrl = this.router.createUrlTree(['t'], { queryParams }).toString();


    //  const domain = 'http://localhost:4200'; // Replace with your actual domain

    const domain = window.location.origin;  // This gets the protocol (http or https) and domain (e.g., localhost:4200 or example.com)

    return domain + dynamicUrl;
  }


  qrCodeData: string = '';

  updateQrCode(): void {
    // Generate the full URL and assign it to qrCodeData
    this.qrCodeData = this.generateDynamicUrl();
  }





  // Method to update the URL dynamically




  ngOnInit(): void {
    this.loadData();
    this.loadTimetables();//simple timetable   all data 


    //  this.loadTimetablesgroup();//group time table 
    const currentYear = new Date().getFullYear();
    this.filterYear = currentYear.toString(); // Assign current year as string


    this.route.queryParams.subscribe((params) => {
      this.filterTeacher = params['teacher'] || '';
      this.filterYear = params['year'] || '';
      this.filterBatch = params['batch'] || '';
      this.filterGeneration = params['generation'] || '';
      this.filterGroupStudent = params['group'] || '';
      this.filterSemester = params['semester'] || '';
      this.filterStudyShift = params['studyShift'] || '';
      this.filterMajorName = params['major'] || '';
      this.filterRoom = params['room'] || '';

      // After parsing query parameters, reapply filters  with 10s
      this.filterTimetables();


      this.updateQrCode(); // Automatically update the QR code when query parameters are parsed



      setTimeout(() => {
        // Apply filters and load timetables after 10 seconds
        this.filterTimetables();

      }, 1000); // 10000 milliseconds = 10 seconds
    });


  }





  get uniqueRoom() {
    const rooms = this.timetables.map(t => t.room_number);
    return [...new Set(rooms)];
  }
  get uniqueYears() {
    const years = this.timetables.map(t => t.years);
    return [...new Set(years)];
  }

  get uniqueStudyShifts() {
    const studyShifts = this.timetables.map(t => t.study_shift_name);
    return ['All', ...new Set(studyShifts)];
  }

  get uniqueGroupStudents() {
    const groupStudents = this.timetables.map(t => t.group_student);
    return [...new Set(groupStudents)];
  }
  get uniqueSemesters() {
    const semesters = this.timetables.map(t => t.semester);
    return [...new Set(semesters)];
  }
  get uniqueGenerations() {
    const generations = this.timetables.map(t => t.generation);
    return [...new Set(generations)];
  }
  get uniqueMajors() {
    const majors = this.timetables.map(t => t.major_name);
    return [...new Set(majors)];
  }
  get uniqueBatch() {
    const batches = this.timetables.map(t => t.batch);
    return [...new Set(batches)];
  }
  get uniqueTeachers() {
    // Extract unique teacher IDs from timetables and map them to teacher names
    const teacherIds = [...new Set(this.timetables.map(t => t.teacher_id))];
    return teacherIds.map(id => ({
      id,
      name: this.findTeacher(id),
    }));
  }













  // Method to filter timetables based on the filter criteria
  filterTimetables(): void {
    this.isLoading = true

    let filteredTimetables = this.timetables;

    if (this.filterTeacher) {
      filteredTimetables = filteredTimetables.filter(entry =>
        this.findTeacher(entry.teacher_id).toLowerCase().includes(this.filterTeacher.toLowerCase()));
    }
    // Filter by study shift name
    if (this.filterStudyShift && this.filterStudyShift !== 'All') {
      filteredTimetables = filteredTimetables.filter(entry =>
        entry.study_shift_name.toLowerCase().includes(this.filterStudyShift.toLowerCase())
      );
    }


    // Filter based on batch
    if (this.filterBatch) {
      filteredTimetables = filteredTimetables.filter(entry => entry.batch.toString() === this.filterBatch);
    }
    // Filter based on generation
    if (this.filterGeneration) {
      filteredTimetables = filteredTimetables.filter(entry => entry.generation.toString() === this.filterGeneration);
    }
    // Filter based on group_student
    if (this.filterGroupStudent) {
      filteredTimetables = filteredTimetables.filter(entry => entry.group_student.toString() === this.filterGroupStudent);
    }
    // Filter based on semester
    if (this.filterSemester) {
      filteredTimetables = filteredTimetables.filter(entry => entry.semester.toString() === this.filterSemester);
    }

    // Filter based on year
    if (this.filterYear) {
      filteredTimetables = filteredTimetables.filter(entry => entry.years.toString() === this.filterYear);
    }

    // Filter based on major_name
    if (this.filterRoom) {
      filteredTimetables = filteredTimetables.filter(entry => entry.room_number.toString() === this.filterRoom);
    }

    if (this.filterMajorName) {
      filteredTimetables = filteredTimetables.filter(entry => entry.major_name.toString() === this.filterMajorName);
    }

    // Group by time and day after filtering
    this.groupedTimetables = this.groupTimetablesByTimeAndDay(filteredTimetables);
    this.isLoading = false

  }


  groupTimetablesByTimeAndDay(timetables: any[]): any[] {
    this.isLoading = true
    if (!timetables || timetables.length === 0) return []; // Handle empty input​​​ ​Saturday​ Sunday  "​Saturday​"

    const validDays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
    const grouped: any[] = [];

    timetables.forEach((entry) => {
      const {
        session_time_start,
        session_time_end,
        study_session_day,
        study_sessions_id,
        study_shift_name,
        subject_name,
        teacher_id,
        room_id,
        room_number,
        id,
        major_name,
        generation,
        batch,

      } = entry;

      if (!validDays.includes(study_session_day)) return; // Skip invalid days

      const timeRange = `${session_time_start} - ${session_time_end} `;

      // Check if the time slot exists in the grouped array
      let timeSlot = grouped.find((slot) => slot.time === timeRange);

      if (!timeSlot) {
        // If not found, create a new time slot entry
        timeSlot = { time: timeRange };
        grouped.push(timeSlot);
      }

      // Add the entry under the corresponding day
      timeSlot[study_session_day] = {
        subject_name,
        teacher_id,
        room_id,
        study_sessions_id,
        study_shift_name,
        generation,
        room_number,
        batch,
        major_name,
        id,
      };
    });

    // Optionally sort the grouped array by time for better presentation
    grouped.sort((a, b) => {
      const [aStart] = a.time.split(" - ");
      const [bStart] = b.time.split(" - ");
      return new Date(`1970/01/01 ${aStart}`).getTime() - new Date(`1970/01/01 ${bStart}`).getTime();
    });
    this.isLoading = false

    return grouped;
  }
  groupedTimetables: any[] = [];
  formatTime(time: string): string {
    const [hours, minutes] = time.split(':');
    const period = +hours >= 12 ? 'PM' : 'AM';
    const formattedHours = +hours > 12 ? +hours - 12 : +hours;
    return `${formattedHours}:${minutes} ${period}`;
  }







  // Load related data (teachers, majors, rooms, study sessions)
  loadData(): void {


    this.isLoading = true;
    // Fetch teachers
    this.apiService.getTeachers().subscribe(
      (response) => (this.teachers = response),
      (error) => console.error('Error loading teachers:', error)
    );
    // Fetch majors
    this.apiService.getMajors().subscribe(
      (response) => (this.majors = response),
      (error) => console.error('Error loading majors:', error)
    );

    // Fetch rooms
    this.apiService.getRooms().subscribe(
      (response) => (this.rooms = response),
      (error) => console.error('Error loading rooms:', error)
    );
    // Fetch study sessions
    this.apiService.getStudySessions().subscribe(
      (response) => (this.studySessions = response),
      (error) => console.error('Error loading study sessions:', error)
    );


  }
  loadTimetables(): void {
    this.isLoading = true
    this.apiService.getTimetable().subscribe(
      (response) => {
        this.timetables = response.timetable_entries || response;
        this.isLoading = false;
      },
      (error) => {
        console.error('Error loading timetables:', error);
        this.message?.error('Failed to load timetables');
        this.isLoading = false;
      }
    );
  }


  loadTimetablesgroup(): void {
    this.isLoading = true
    this.apiService.getTimetable().subscribe(
      (response) => {
        this.timetables = response.timetable_entries || response;
        this.isLoading = false;

        // Grouping by time and day
        this.groupedTimetables = this.groupTimetablesByTimeAndDay(this.timetables);
      },
      (error) => {
        console.error('Error loading timetables:', error);
        this.message?.error('Failed to load timetables');
        this.isLoading = true;
      }
    );
  }




  // Find teacher name by ID
  findTeacher(teacherId: number): string {
    const teacher = this.teachers.find((t) => t.id === teacherId);
    return teacher ? teacher.name : 'Unknown';
  }
  // Find room details by ID
  findRoom(roomId: number): any {
    return this.rooms.find((r) => r.id === roomId) || { room_type: 'Unknown', room_number: 'Unknown', floor: 'Unknown', capacity: 'Unknown' };
  }
  findStudySession(sessionId: number): any | null {
    const session = this.studySessions.find((s) => s.id === sessionId);
    return session || null;
  }


  // Find subject name by ID
  findSubject(subjectId: number): string {
    const subject = this.majors.find((s) => s.id === subjectId);
    return subject ? subject.major_name : 'Unknown';
  }



}
