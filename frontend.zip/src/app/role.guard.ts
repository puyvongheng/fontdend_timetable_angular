import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class RoleGuard implements CanActivate {





  canActivate(route: ActivatedRouteSnapshot): boolean {


    const teacherDetails = localStorage.getItem('teacherDetails');
    const studentDetails = localStorage.getItem('studentDetails');




    // If teacherDetails exist, parse them and check the 
    if (teacherDetails) {
      const teacher = JSON.parse(teacherDetails);
      const allowedRoles = route.data['roles'] as Array<string>;

      if (allowedRoles.includes(teacher.role)) {
        console.log('Access Granted');
        return true;
      }
    }



    console.log('Access Denied');
    return false; // Redirect unauthorized users



    /*  // If no teacherDetails but studentDetails exist, allow public access
      if (studentDetails) {
        return route.data['allowStudent'] || false; // Allow access only if explicitly permitted
      }
  
      // Redirect unauthorized users to the login page
      this.router.navigate(['/login']);
      return false;
    }
  */

  }
}
