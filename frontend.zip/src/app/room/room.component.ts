import { Component, OnInit } from '@angular/core';
import { ApiService } from '../service/api.service';

import { SharedModule } from '../shared/shared.module';

@Component({
  selector: 'app-room',
  imports: [
    SharedModule,

  ],
  templateUrl: './room.component.html',
  styleUrl: './room.component.css'
})
export class RoomComponent implements OnInit {
  rooms: any[] = []; // Array to hold room data
  roomNumber: string = ''; // Room number input
  capacity: number | null = null; // Room capacity input
  floor: number | null = null; // Room floor input
  roomType: string = ''; // Room type input
  selectedRoomId: number | null = null; // The selected room for editing

  constructor(private apiService: ApiService) { }


  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.apiService.getRooms().subscribe((response) => { this.rooms = response; });
  }


  private createRoomObject(): any {
    return {
      room_number: this.roomNumber,
      capacity: this.capacity,
      floor: this.floor,
      room_type: this.roomType
    };
  }


  addRoom(): void {
    if (this.roomNumber.trim() && this.capacity && this.floor && this.roomType) {

      const newRoom = {
        room_number: this.roomNumber,
        capacity: this.capacity,
        floor: this.floor,
        room_type: this.roomType

      };

      this.apiService.createroom(newRoom).subscribe(
        (response) => {
          console.log('Room added successfully', response);
          this.load(); // Reload rooms after adding
          this.clearForm(); // Clear the form
        },
        (error) => {
          console.error('Error adding room:', error);
          if (error.status === 500) {
            alert('Server error occurred. Please try again later.');
          } else if (error.status === 0) {
            alert('Network error. Please check your internet connection.');
          } else {
            alert(`Error: ${error.message}`);
          }
        }
      );


    } else {
      alert('Please provide all room details!');
    }
  }

  // Edit a room
  editRoom(id: number): void {
    const room = this.rooms.find(r => r.id === id);
    if (room) {
      this.selectedRoomId = id;
      this.roomNumber = room.room_number;
      this.capacity = room.capacity;
      this.floor = room.floor;
      this.roomType = room.room_type;
    }
  }

  // Update an existing room
  updateRoom(): void {
    if (this.selectedRoomId && this.roomNumber.trim() && this.capacity && this.floor && this.roomType) {
      const updatedRoom = {
        room_number: this.roomNumber,
        capacity: this.capacity,
        floor: this.floor,
        room_type: this.roomType
      };

      this.apiService.update('rooms', this.selectedRoomId, updatedRoom).subscribe(
        () => {
          this.load(); // Reload rooms after update
          this.clearForm(); // Clear the form
          this.selectedRoomId = null; // Reset selected room ID
        },
        (error) => {
          console.error('Error updating room:', error);
        }
      );
    }
  }

  // Delete a room
  deleteRoom(id: number): void {
    if (confirm('Are you sure you want to delete this room?')) {
      this.apiService.delete('rooms', id).subscribe(
        () => {
          this.load(); // Reload rooms after deletion
        },
        (error) => {
          console.error('Error deleting room:', error);
        }
      );
    }
  }

  // Clear form inputs
  clearForm(): void {
    this.roomNumber = '';
    this.capacity = null;
    this.floor = null;
    this.roomType = '';
  }
}