import { Component } from '@angular/core';
import { AuthService } from '../service/auth.service';

import {  NzIconService } from 'ng-zorro-antd/icon';
import { NzMessageService } from 'ng-zorro-antd/message';

import { FileTextOutline, FolderOutline, HomeOutline, InsertRowAboveOutline, PieChartOutline, PlusOutline, SolutionOutline, TeamOutline, UserOutline } from '@ant-design/icons-angular/icons';
import { SharedModule } from '../shared/shared.module';

@Component({
  selector: 'app-navleft',
  imports: [
    SharedModule,
  
  
  ],
  templateUrl: './navleft.component.html',
  styleUrl: './navleft.component.css'
})
export class NavleftComponent {




  constructor(
    private iconService: NzIconService,
    private message: NzMessageService
  ) {
    this.iconService.addIcon(
      UserOutline,
      HomeOutline,
      PieChartOutline,
      InsertRowAboveOutline,
      PlusOutline,
      SolutionOutline,
      FolderOutline,
      TeamOutline,
      FileTextOutline
    );
  }


  isWrapperVisible: boolean = true;  // Initially show the menu

  toggleWrapperVisibility(): void {
    this.isWrapperVisible = !this.isWrapperVisible;  // Toggle visibility
  }



  isCollapsed = true;


  toggleCollapsed(): void {
    this.isCollapsed = !this.isCollapsed;
  }


}
