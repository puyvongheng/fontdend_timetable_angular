import { Component } from '@angular/core';
import { AuthService } from '../service/auth.service';

import { SharedModule } from '../shared/shared.module';
declare var bootstrap: any;  // Declare Bootstrap to access the collapse functionality



@Component({
  selector: 'app-navbar',
  imports: [
    
    
    SharedModule,
    
    
  
  ],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent {


  // Login method to simulate login action



  studentDetails: any = null;
  teacherDetails: any = null;
  router: any;
  constructor(private authService: AuthService) { }

  isNavbarOpen = false; // Track whether the navbar is open or closed

  toggleNavbar() {
    this.isNavbarOpen = !this.isNavbarOpen;  // Toggle navbar open/close
  }


  closeNavbar() {
    this.isNavbarOpen = false;  // Set navbar to closed
    // Get the collapse element
    const navbarCollapse = document.getElementById('navbarNav');
    const bsCollapse = new bootstrap.Collapse(navbarCollapse, {
      toggle: false  // Prevent it from toggling, just collapsing
    });
    bsCollapse.hide();  // Manually close the navbar
  }


  // Method to log out the user
  logout() {
    this.authService.logout();  // Call the logout method from AuthService
    //window.location.reload();  // This reloads the page

  }

  ngOnInit() {





    const storedTeacherDetails = localStorage.getItem('teacherDetails');
    if (storedTeacherDetails) {
      this.teacherDetails = JSON.parse(storedTeacherDetails);
    } else {
      // Handle the case if no student details are found in storage
      console.error("No student details found.");
    }



    // Get student details from localStorage (or sessionStorage)
    const storedStudentDetails = localStorage.getItem('studentDetails');
    if (storedStudentDetails) {
      this.studentDetails = JSON.parse(storedStudentDetails);
    } else {
      // Handle the case if no student details are found in storage
      console.error("No student details found.");
    }


    
  }







}
