import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  private baseUrl: string = 'https://puyvongheng.online/api/';

  constructor(private http: HttpClient) { }



  // PUT ----------------- Update Teacher
  updateTeacher(teacherId: number, updatedData: any): Observable<any> {
    return this.http.put(`${this.baseUrl}teachers/admin/${teacherId}`, updatedData);

  }
  

  // POST -----------------su

  //can used all
  create(endpoint: string, data: any): Observable<any> {
    return this.http.post(`${this.baseUrl}${endpoint}`, data);
  }

  createroom(data: any): Observable<any> {
    return this.http.post(`${this.baseUrl}rooms`, data);
  }




  assignSubjectToTeacher(teacherId: number, subjectId: number): Observable<any> {
    const data = {
      teacher_id: teacherId,
      subject_id: subjectId
    };
    return this.create('teacher_subjects', data);
  }

  createFaculties(endpoint: string, data: any): Observable<any> {
    return this.http.post(`${this.baseUrl}${endpoint}`, data);
  }




  //PUT -------------------  UPDATE



  //can used all
  update(endpoint: string, id: number, data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}${endpoint}/${id}`, data);
  }




  updatrole(endpoint: string, data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}${endpoint}`, data);
  }


  updateFaculties(endpoint: string, id: number, data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}${endpoint}/${id}`, data);
  }





  //DELETE-------------------

  //can used all
  delete(endpoint: string, id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}${endpoint}/${id}`);
  }


  deleteTeacherSubject(teacherId: number, subjectId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}teacher_subjects`, {
      body: { teacher_id: teacherId, subject_id: subjectId }
    });
  }




  deleteFaculties(endpoint: string, id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}${endpoint}/${id}`);
  }










  //GET----------------------

  //can used all

  get(endpoint: string): Observable<any> {
    return this.http.get(`${this.baseUrl}${endpoint}`);
  }



  getstuden(endpoint: string, page: number = 1, pageSize: number = 10): Observable<any> {
    const params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());

    return this.http.get(`${this.baseUrl}${endpoint}`, { params });
  }

  checkUsernameAvailability(username: string): Observable<any> {
    return this.http.get(`${this.baseUrl}teachers/username/${username}`);
  }

  getMajors(): Observable<any> {
    return this.http.get(`${this.baseUrl}majors`);
  }


  getFaculties(): Observable<any> {
    return this.http.get(`${this.baseUrl}faculties`);
  }


  getDepartments(): Observable<any> {
    return this.http.get(`${this.baseUrl}departments`);
  }

  getRooms(): Observable<any> {
    return this.http.get(`${this.baseUrl}rooms`);
  }

  getStudents(): Observable<any> {
    return this.http.get(`${this.baseUrl}students`);
  }

  getStudySessions(): Observable<any> {
    return this.http.get(`${this.baseUrl}study_sessions`);
  }

  getSubjects(): Observable<any> {
    return this.http.get(`${this.baseUrl}subjects`);
  }

  getTeacherSubjects(): Observable<any> {
    return this.http.get(`${this.baseUrl}teacher_subjects`);
  }

  getTeachers(): Observable<any> {
    return this.http.get(`${this.baseUrl}teachers`);
  }

  getTimetable(): Observable<any> {
    return this.http.get(`${this.baseUrl}timetable`);
  }













}
