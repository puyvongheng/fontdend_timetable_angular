import { Component, OnInit } from '@angular/core';
import { ApiService } from '../service/api.service';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { SharedModule } from '../shared/shared.module';


@Component({
  selector: 'app-study-session',
  imports: [
    SharedModule,
  
  ],
  templateUrl: './study-session.component.html',
  styleUrl: './study-session.component.css'
})
export class StudySessionComponent implements OnInit {
  studySessions: any[] = [];
  newSession: any = {};
  isEditing: boolean = false;
  sessionToEdit: any = null;
  toastr: any;

  constructor(private apiService: ApiService,

    private NzMessageService: NzMessageService,
    private notification: NzNotificationService
  ) { }

  ngOnInit(): void {
    this.loadStudySessions();
  }

  // Load existing study sessions
  loadStudySessions() {
    this.apiService.getStudySessions().subscribe((response: any) => { this.studySessions = response; });
  }

  addStudySession() {

    this.apiService.create('study_sessions', this.newSession).subscribe(
      (response) => {
        this.toastr.success('Study session added successfully');
        this.loadStudySessions(); // Reload sessions
        this.newSession = {}; // Reset form

      },
      (error) => {
        this.toastr.error('Failed to add study session');
      }
    );
  }

  // Edit a study session (populate form with session data)
  editSession(session: any) {
    this.isEditing = true;
    this.newSession = { ...session }; // Copy session data to form
    this.sessionToEdit = session; // Store the session to edit
    this.loadStudySessions();

  }

  // Update the existing study session
  updateStudySession() {
    this.apiService.update('study_sessions', this.sessionToEdit.id, this.newSession).subscribe(
      (response) => {
        this.toastr.success('Study session updated successfully');
        this.loadStudySessions(); // Reload sessions
        this.newSession = {}; // Reset form
        this.isEditing = false; // Reset edit mode
      },
      (error) => {
        this.toastr.error('Failed to update study session');
      }
    );
  }

  // Delete a study session
  deleteSession(sessionId: number): void {
    this.apiService.delete('study_sessions', sessionId).subscribe(
      (response) => {
        this.toastr.success('Study session deleted successfully');
        this.loadStudySessions(); // Reload sessions
      },
      (error) => {
        this.toastr.error('Failed to delete study session');
      }
    );
  }

  cancel(): void {
    // Handle cancel action if needed (e.g., log or perform other cleanup actions)
    console.log('Delete canceled');
  }




}