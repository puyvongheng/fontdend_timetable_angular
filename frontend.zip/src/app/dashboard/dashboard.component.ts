import { ApiService } from './../service/api.service';
import { Component, CUSTOM_ELEMENTS_SCHEMA, OnInit } from '@angular/core';


import { SharedModule } from '../shared/shared.module';
import { TreeNode } from 'primeng/api';

@Component({
  selector: 'app-dashboard',
  imports: [

       SharedModule,
   
  ],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css',
  schemas: [CUSTOM_ELEMENTS_SCHEMA], // Add this line

})
export class DashboardComponent implements OnInit {

  faculties: any[] = []; // Array to hold the faculties
  departments: any[] = [];
  majors: any[] = [];
  students: any[] = [];
  rooms: any[] = [];
  subjects: any[] = [];
  teachers: any[] = [];
  timetables: any[] = [];




  data: TreeNode[] = [
    {
      label: 'មហាវិទ្យាល័យ',
      expanded: true,
      data: 'ar',
      children: [
        {
          label: 'faculties.name',
          expanded: true,
          data: 'ar',
          children: [
            {
              label: 'departments.name',
              data: 'ar',
              children: [
                {
                  label: 'majors.name',
                  data: 'ar'
                },
             
              ]
            },
          ]
        },


        {
          label: 'គ្រប់គ្រងពាណិជ្ជកម្ម និងទេសចរណ៍', //faculties.name
          expanded: true,
          data: 'fr',
          children: [
            {
              label: 'គណនេយ្យនិងហិរញ្ញវត្ថុ', //departments.name
              data: 'fr',
              children: [
                {
                  label: 'Accounting',//majors.name
                  data: 'ma'
                },
                {
                  label: 'Finance',
                  data: 'fr'
                }
              ]
            },
            {
              label: 'សហគ្រិនភាពនិងធុរកិច្ច(គ្រប់គ្រងពាណិជ្ជកម្ម)',
              data: 'ma',
              children: [
                {
                  label: 'Small Business',
                  data: 'fr'
                },
                {
                  label: 'Marketing',
                  data: 'ma'
                }
              ]
            }
          ]
        },
        {
          label: 'មហាវិទ្យាល័យ សិល្ប:មនុស្សសាស្ត្រ និងភាសា',
          expanded: true,
          data: 'fr',
          children: [
            {
              label: 'អក្សរសាស្ត្រខ្មែរ',
              data: 'fr',
              children: [
                {
                  label: 'Classical Literature',
                  data: 'ar'
                },
                {
                  label: 'Modern Literature',
                  data: 'fr'
                }
              ]
            },
            {
              label: 'ភាសាអង់គ្លេស',
              data: 'ma',
              children: [
                {
                  label: 'Literature Studies',
                  data: 'ar'
                },
                {
                  label: 'Language Studies',
                  data: 'fr'
                }
              ]
            },
            {
              label: 'ភាសាកូរ៉េ',
              data: 'ma'
            },
            {
              label: 'ភាសាចិន',
              data: 'ma'
            }
          ]
        }
      ]
    }
  ];
/*
  data: TreeNode[] = [];
*/


  constructor(private ApiService: ApiService) {

  }
  ngOnInit(): void {

    this.loadData()

 
  }

  buildData() {
    this.data = [
      {
        label: 'មហាវិទ្យាល័យ',
        expanded: true,
        data: 'id', // This could be the faculty's ID, but it seems you want a string here, adjust as needed.

        children: this.faculties.map(facultie => ({
          label: facultie.name, // Faculty name
          expanded: true,
          data: 'ar', // You can update this as needed for localization or other info

          /*
          // Children: departments and majors based on the faculty
          children: this.departments
            .filter(department => department.facultyId === facultie.id) // Filter departments by faculty
            .map(department => ({
              label: department.name, // Department name
              data: 'ar', // You can change this for departments as well
              children: this.majors
                .filter(major => major.departmentId === department.id) // Filter majors by department
                .map(major => ({
                  label: major.major_name, // Major name
                  data: 'ar' // Again, you can modify this if needed
                }))
            }))
            
            */
        }))
      }
    ];
  }


  getMajorsNotInTimetable(): any[] {
    // Extract all the major_name values in the timetables
    const timetableMajors = this.timetables.map(entry => entry.major_name);

    // Filter the majors that are not found in the timetableMajors array
    return this.majors.filter(major =>
      !timetableMajors.includes(major.major_name)
    );
  }




  getFilteredMajors(): string[] {
    const uniqueMajors = new Set<string>();

    // Add major_name to the Set (Set automatically removes duplicates)
    this.timetables.forEach(entry => {
      if (entry.major_name) {
        uniqueMajors.add(entry.major_name);
      }
    });

    // Convert Set to an array and return it
    return Array.from(uniqueMajors);
  }


  // Method to count subjects by role
  countTeachersByRole(role: string): number {
    return this.teachers.filter(teacher => teacher.role === role).length;
  }


  loadData(): void {

    this.ApiService.getTimetable().subscribe(
      (response) => {
        console.log('API Response for timetables:', response);
        this.timetables = Array.isArray(response.timetable_entries) ? response.timetable_entries : [];
      },
      (error) => console.error('Error loading timetables:', error)
    );


    this.ApiService.getDepartments().subscribe(
      (response) => (this.departments = response),
      (error) => console.error('Error loading data:', error)
    );

    this.ApiService.getFaculties().subscribe(
      (response) => (this.faculties = response),
      (error) => console.error('Error loading data:', error)
    );

    this.ApiService.getMajors().subscribe(
      (response) => (this.majors = response),
      (error) => console.error('Error loading data:', error)
    );


    this.ApiService.getStudents().subscribe(
      (response) => (this.students = response),
      (error) => console.error('Error loading data:', error)
    );


    this.ApiService.getRooms().subscribe(
      (response) => (this.rooms = response),
      (error) => console.error('Error loading data:', error)
    );

    this.ApiService.getSubjects().subscribe(
      (response) => (this.subjects = response),
      (error) => console.error('Error loading data:', error)
    );

    this.ApiService.getTeachers().subscribe(
      (response) => (this.teachers = response),
      (error) => console.error('Error loading data:', error)
    );









  }




}
